﻿namespace CmsApi.Enums
{
    public enum ReferenceDataType
    {
        CaseTypes,
        CaseStatuses,
        MeetingStatuses,
        Courts,
        Judges,
        MeetTypes,
        CourtTypes,
        RealEstateTypes,
        RegionalOffices,
        ComplaintStatuses,
        PretenseStatuses
    }
}
