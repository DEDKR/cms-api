﻿using CmsApi.Common;
using CmsApi.DTOs.ApiDtos;
using CmsApi.DTOs.BorderDtos;
using CmsApi.DTOs.DocumentDtos;
using CmsApi.DTOs.HttpApiDtos;
using CmsApi.Helpers;
using CmsApi.Http.Handlers.Interfaces;
using CmsApi.Services.Interfaces;
using Microsoft.Extensions.Options;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;

namespace CmsApi.Http.Handlers.Implementations
{
    public class CmsHttpHandler : ICmsHttpHandler
    {
        private readonly HttpClient _httpClient;
        private readonly CmsApiSettings _apiSettings;
        private readonly ILogger<CmsHttpHandler> _logger;
        private readonly IECmsAuthService _ecmsAuthService;

        public CmsHttpHandler(
         HttpClient httpClient,
         IOptions<CmsApiSettings> options,
         ILogger<CmsHttpHandler> logger
,
         IECmsAuthService ecmsAuthService)
        {
            _httpClient = httpClient;
            _apiSettings = options.Value;
            _logger = logger;
            _ecmsAuthService = ecmsAuthService;
        }

        public async  Task<CmsApiResponse<DocumentDto>> GetDocumentAsBase64Async(string attachmentId)
        {
            try
            {
                var token = TokenCache.Get();

                if (token is null || token.AccessTokenExpire <= DateTime.UtcNow.AddMinutes(1))
                {
                    await _ecmsAuthService.RefreshTokenAsync();
                    token = TokenCache.Get();
                }

                _httpClient.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", token.AccessToken);

                var url = $"{_apiSettings.FileReaderApi}?attachmentId={Uri.EscapeDataString(attachmentId)}";


                var response = await _httpClient.GetAsync(url);

                var jsonString = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    _logger.LogError(
                        "GetNotificationDetail request failed. StatusCode: {StatusCode}, Response: {Response}",
                        response.StatusCode,
                        jsonString);

                    return null;
                }

                if (response.StatusCode == HttpStatusCode.Unauthorized)
                {
                    _logger.LogWarning("Case Detail API token expired. Refresh olunur.");

                    await _ecmsAuthService.RefreshTokenAsync();

                    token = TokenCache.Get();

                    _httpClient.DefaultRequestHeaders.Authorization =
                        new AuthenticationHeaderValue("Bearer", token.AccessToken);

                    response = await _httpClient.GetAsync(url);
                    jsonString = await response.Content.ReadAsStringAsync();
                }

                var result = JsonSerializer.Deserialize<CmsApiResponse<DocumentDto>>(
                    jsonString,
                    new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });

                if (result.StatusCode == StatusCodes.Status401Unauthorized)
                {
                    _logger.LogWarning("Case Detail API token expired. Refresh olunur.");

                    await _ecmsAuthService.RefreshTokenAsync();

                    token = TokenCache.Get();

                    _httpClient.DefaultRequestHeaders.Authorization =
                        new AuthenticationHeaderValue("Bearer", token.AccessToken);

                    response = await _httpClient.GetAsync(url);
                    jsonString = await response.Content.ReadAsStringAsync();

                    result = JsonSerializer.Deserialize<CmsApiResponse<DocumentDto>>(
                        jsonString,
                        new JsonSerializerOptions
                        {
                            PropertyNameCaseInsensitive = true
                        });
                }


                if (result is null)
                {
                    _logger.LogError("Notification detail response deserialize olunmadı.");
                    return null;
                }

                if (result.StatusCode == StatusCodes.Status401Unauthorized)
                {
                    _logger.LogWarning(
                        "Notification Detail API token expired. Message: {Message}",
                        result.ResponseException?.ExceptionMessage);
                }

                if (!result.IsSuccess)
                {
                    _logger.LogWarning(
                        "Notification Detail API business error. StatusCode: {StatusCode}, Message: {Message}",
                        result.StatusCode,
                        result.ResponseException?.ExceptionMessage ?? result.Message);

                    return result;
                }

                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Exception occurred while getting notification detail.");

                return null;
            }
        }

        public async Task<bool> SetAsReadAsync(string notificationId)
        {
            try
            {
                var token = TokenCache.Get();

                if (token is null || token.AccessTokenExpire <= DateTime.UtcNow)
                {
                    await _ecmsAuthService.RefreshTokenAsync();
                    token = TokenCache.Get();
                }

                _httpClient.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", token.AccessToken);

                var content = new StringContent(
                    JsonSerializer.Serialize(new
                    {
                        value = notificationId
                    }),
                    Encoding.UTF8,
                    "application/json");

                var response = await _httpClient.PostAsync(
                    _apiSettings.NotificationReadApi,
                    content);

                var responseContent = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    _logger.LogError(
                        "SetAsRead request failed. StatusCode: {StatusCode}, Response: {Response}",
                        response.StatusCode,
                        responseContent);

                    return false;
                }

                _logger.LogInformation(
                    "Notification {NotificationId} marked as read successfully.",
                    notificationId);

                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex,
                    "Exception occurred while setting notification as read.");

                return false;
            }
        }


        public async Task<JsonElement?> GetBordersAsync()
        {
            try
            {
                // 1. Get token
                var tokenRequest = new BorderTokenRequestDto
                {
                    ClientId = _apiSettings.BorderClientId,
                    ClientSecret = _apiSettings.BorderClientSecret
                };

                var tokenJson = JsonSerializer.Serialize(tokenRequest);

                using var tokenContent = new StringContent(
                    tokenJson,
                    Encoding.UTF8,
                    "application/json");

                var tokenResponse = await _httpClient.PostAsync(
                    _apiSettings.BorderTokenApi,
                    tokenContent);

                var tokenResponseJson =
                    await tokenResponse.Content.ReadAsStringAsync();

                if (!tokenResponse.IsSuccessStatusCode)
                {
                    _logger.LogError(
                        "Border token request failed. StatusCode: {StatusCode}, Response: {Response}",
                        tokenResponse.StatusCode,
                        tokenResponseJson);

                    return null;
                }

                var token = JsonSerializer.Deserialize<BorderTokenResponseDto>(
                    tokenResponseJson);

                if (token is null || string.IsNullOrWhiteSpace(token.AccessToken))
                {
                    _logger.LogError("Border access token alınmadı.");
                    return null;
                }

                // 2. Pass the token in GET /api/borders
                using var request = new HttpRequestMessage(
                    HttpMethod.Get,
                    _apiSettings.BordersApi);

                request.Headers.Authorization =
                    new AuthenticationHeaderValue(
                        "Bearer",
                        token.AccessToken);

                var response = await _httpClient.SendAsync(request);

                var bordersJson =
                    await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    _logger.LogError(
                        "Borders request failed. StatusCode: {StatusCode}, Response: {Response}",
                        response.StatusCode,
                        bordersJson);

                    return null;
                }

                // 3. Do not create a strict DTO
                using var document = JsonDocument.Parse(bordersJson);

                return document.RootElement.Clone();
            }
            catch (Exception ex)
            {
                _logger.LogError(
                    ex,
                    "Exception occurred while getting borders.");

                return null;
            }
        }


    }
}
